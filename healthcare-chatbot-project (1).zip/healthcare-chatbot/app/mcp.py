"""MCP-style tool layer: each tool has an RBAC allow-list and reads from the SQL DB.
(To expose these as a real MCP server, wrap the functions with the official `mcp` SDK.)"""
import re
from .db import Patient, Appointment, LabResult, User

ALLOWED = {"Patient": {"patient", "doctor"}, "Lab": {"patient", "doctor"}, "Appointment": {"patient", "doctor", "hospital"},
           "Doctor": {"doctor", "hospital"}, "Hospital": {"hospital"}}

def pick_tool(q):
    l = q.lower()
    if re.search(r"\b(labs?|results?|tests?)\b", l): return "Lab"
    if re.search(r"appointment|book|slot|schedule", l): return "Appointment"
    if re.search(r"occupancy|beds|hospital stat", l): return "Hospital"
    if re.search(r"availab|list of doctors|which doctors", l): return "Doctor"
    if re.search(r"p-\d+|\bhistory\b|my record|patient record|my details", l): return "Patient"
    return None

def target_patient(q, user, db):
    if user.role == "patient": return db.get(Patient, user.patient_id)  # patients can only see themselves
    m = re.search(r"p-\d+", q.lower())
    code = m.group(0).upper() if m else "P-1001"
    return db.query(Patient).filter_by(code=code).first()

def run(q, user, db):
    tool = pick_tool(q)
    if not tool: return None, None
    if user.role not in ALLOWED[tool]: raise PermissionError(tool)
    src = f"{tool} MCP · live record"
    if tool == "Hospital":
        n = db.query(Appointment).count()
        return f"Booked appointments: {n}. Bed occupancy (demo data): General 78%, ICU 91%, Maternity 64%.", src
    if tool == "Doctor":
        docs = {a.doctor for a in db.query(Appointment).all()}
        return "Doctors with scheduled appointments:\n" + "\n".join(f"- {d}" for d in sorted(docs)), src
    p = target_patient(q, user, db)
    if not p: return "Patient not found.", src
    if tool == "Patient":
        return f"{p.code} · {p.name}, {p.age}\nConditions: {p.conditions}\nMedication: {p.meds}", src
    if tool == "Lab":
        rows = db.query(LabResult).filter_by(patient_id=p.id).all()
        return f"Lab results for {p.code}:\n" + "\n".join(f"- {r.test}: {r.value} ({r.date})" for r in rows), src
    if re.search(r"book", q.lower()):
        a = Appointment(patient_id=p.id, doctor="Dr. Meera Iyer (Cardiology)", slot="2026-10-08 11:00"); db.add(a); db.commit()
        return f"Booked: {a.doctor} on {a.slot}.", src
    rows = db.query(Appointment).filter_by(patient_id=p.id).all()
    return f"Appointments for {p.code}:\n" + "\n".join(f"- {a.slot} · {a.doctor} [{a.status}]" for a in rows), src
