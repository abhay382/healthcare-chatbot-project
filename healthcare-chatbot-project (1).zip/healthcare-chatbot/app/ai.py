import os, re, uuid, httpx, chromadb
from pathlib import Path
BASE = Path(__file__).resolve().parent.parent

BACKEND = os.getenv("PRIVATE_LLM_BACKEND", "ollama")   # ollama | openai (vLLM, llama.cpp, LM Studio) | hf (local files)
LLM_URL = os.getenv("PRIVATE_LLM_URL", os.getenv("OLLAMA_URL", "http://localhost:11434"))
LLM = os.getenv("PRIVATE_LLM", "llama3.1")             # model name, or local folder path for hf
EMB = os.getenv("EMBED_MODEL", "nomic-embed-text")
HDR = {"Authorization": "Bearer " + os.getenv("PRIVATE_LLM_API_KEY", "none")}
col = chromadb.PersistentClient(str(BASE / "chroma")).get_or_create_collection("hospital_kb", metadata={"hnsw:space": "cosine"})
_hf = {}

SEED = [
 ("Hospital Policies · Discharge", "Policy", "A patient may be discharged only after the treating physician signs the discharge summary, medications are reconciled and a follow-up visit is scheduled."),
 ("FAQs · Visiting hours", "FAQ", "Visiting hours are 10:00-12:00 and 17:00-19:00. Maximum two visitors per patient. ICU visits need nurse approval."),
 ("Clinical Guidelines · Hypertension", "Guideline", "Confirm hypertension with repeated readings (>=140/90 mmHg). Assess cardiovascular risk, advise lifestyle changes, and start drug therapy by risk and stage. Target is generally below 130/80 mmHg if tolerated."),
]

def _hf_load():
    if not _hf:
        from transformers import pipeline
        from sentence_transformers import SentenceTransformer
        _hf["gen"] = pipeline("text-generation", model=LLM, device_map="auto")
        _hf["emb"] = SentenceTransformer(EMB)
    return _hf

def embed(t):
    if BACKEND == "hf": return _hf_load()["emb"].encode(t).tolist()
    if BACKEND == "openai":
        r = httpx.post(f"{LLM_URL}/v1/embeddings", json={"model": EMB, "input": t}, headers=HDR, timeout=60); r.raise_for_status()
        return r.json()["data"][0]["embedding"]
    r = httpx.post(f"{LLM_URL}/api/embeddings", json={"model": EMB, "prompt": t}, timeout=60); r.raise_for_status()
    return r.json()["embedding"]

def private_llm(messages):
    """Your own LLM - nothing here leaves your servers."""
    if BACKEND == "hf":
        return _hf_load()["gen"](messages, max_new_tokens=512)[0]["generated_text"][-1]["content"]
    if BACKEND == "openai":
        r = httpx.post(f"{LLM_URL}/v1/chat/completions", json={"model": LLM, "messages": messages}, headers=HDR, timeout=180); r.raise_for_status()
        return r.json()["choices"][0]["message"]["content"]
    r = httpx.post(f"{LLM_URL}/api/chat", json={"model": LLM, "messages": messages, "stream": False}, timeout=180); r.raise_for_status()
    return r.json()["message"]["content"]

def status():
    ok = True
    if BACKEND != "hf":
        try: httpx.get(LLM_URL + ("/v1/models" if BACKEND == "openai" else "/api/tags"), headers=HDR, timeout=3).raise_for_status()
        except Exception: ok = False
    return {"private": {"backend": BACKEND, "model": LLM, "online": ok}, "gemini": bool(os.getenv("GEMINI_API_KEY"))}

def chunk(text, n=500):
    out, cur = [], ""
    for para in re.split(r"\n\s*\n|(?<=[.!?])\s+", text):
        if len(cur) + len(para) > n and cur: out.append(cur.strip()); cur = ""
        cur += para + " "
    return out + ([cur.strip()] if cur.strip() else [])

def add_text(text, source, kind="Knowledge"):
    cs = chunk(text)
    col.add(ids=[str(uuid.uuid4()) for _ in cs], documents=cs, embeddings=[embed(c) for c in cs],
            metadatas=[{"source": source, "kind": kind}] * len(cs))
    return len(cs)

def search(q, k=4):
    if col.count() == 0: return []
    r = col.query(query_embeddings=[embed(q)], n_results=min(k, col.count()))
    return list(zip(r["documents"][0], r["metadatas"][0], r["distances"][0]))

def seed():
    if col.count() == 0:
        for src, kind, text in SEED: add_text(text, src, kind)

def rag_answer(q, history):
    try: hits = search(q)
    except Exception: hits = []   # embedding model offline
    sources = sorted({m["source"] for _, m, _ in hits})
    ctx = "\n---\n".join(d for d, _, _ in hits) or "No relevant documents."
    sys = ("You are a hospital assistant. Answer ONLY from the context. If the context is insufficient, say so. "
           "Be concise. Do not give a diagnosis; advise seeing a doctor for personal medical decisions.\n\nContext:\n" + ctx)
    try:
        return private_llm([{"role": "system", "content": sys}, *history, {"role": "user", "content": q}]), sources
    except Exception:  # private LLM offline -> return retrieved text so the app still works
        return "(Private LLM offline - showing retrieved knowledge)\n\n" + ctx, sources

def gemini_answer(q):
    key = os.getenv("GEMINI_API_KEY")
    if not key: raise RuntimeError("GEMINI_API_KEY is not set")
    from google import genai
    from google.genai import types
    res = genai.Client(api_key=key).models.generate_content(
        model=os.getenv("GEMINI_MODEL", "gemini-2.5-flash"),
        contents="Answer concisely using current public information. Do not include any private data.\n\n" + q,
        config=types.GenerateContentConfig(tools=[types.Tool(google_search=types.GoogleSearch())]))
    src = []
    try:
        for c in res.candidates[0].grounding_metadata.grounding_chunks: src.append(c.web.title or c.web.uri)
    except Exception: pass
    return res.text, sorted(set(src)) or ["Gemini web search"]
