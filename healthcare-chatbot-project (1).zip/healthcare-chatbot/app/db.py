import os, hashlib, datetime as dt
from sqlalchemy import create_engine, Column, Integer, String, Text, DateTime, ForeignKey
from sqlalchemy.orm import declarative_base, sessionmaker

from pathlib import Path
URL = os.getenv("DATABASE_URL") or "sqlite:///" + str(Path(__file__).resolve().parent.parent / "health.db")
engine = create_engine(URL, connect_args={"check_same_thread": False} if URL.startswith("sqlite") else {})
Session = sessionmaker(bind=engine, autoflush=False)
Base = declarative_base()
now = dt.datetime.utcnow

class Patient(Base):
    __tablename__ = "patients"
    id = Column(Integer, primary_key=True); code = Column(String(20), unique=True)
    name = Column(String(100)); age = Column(Integer); conditions = Column(Text); meds = Column(Text)
class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True); username = Column(String(50), unique=True)
    pw = Column(String(200)); role = Column(String(20)); name = Column(String(100))
    patient_id = Column(Integer, ForeignKey("patients.id"), nullable=True)
class Appointment(Base):
    __tablename__ = "appointments"
    id = Column(Integer, primary_key=True); patient_id = Column(Integer, ForeignKey("patients.id"))
    doctor = Column(String(100)); slot = Column(String(50)); status = Column(String(20), default="booked")
class LabResult(Base):
    __tablename__ = "lab_results"
    id = Column(Integer, primary_key=True); patient_id = Column(Integer, ForeignKey("patients.id"))
    test = Column(String(100)); value = Column(String(100)); date = Column(String(20))
class Conversation(Base):
    __tablename__ = "conversations"
    id = Column(Integer, primary_key=True); user_id = Column(Integer, ForeignKey("users.id"))
    title = Column(String(200)); created = Column(DateTime, default=now)
class Message(Base):
    __tablename__ = "messages"
    id = Column(Integer, primary_key=True); conv_id = Column(Integer, ForeignKey("conversations.id"))
    role = Column(String(10)); content = Column(Text); route = Column(String(10)); sources = Column(Text, default="[]")
    created = Column(DateTime, default=now)
class Document(Base):
    __tablename__ = "documents"
    id = Column(Integer, primary_key=True); title = Column(String(200)); kind = Column(String(50))
    uploaded_by = Column(Integer, ForeignKey("users.id")); created = Column(DateTime, default=now)
class AuditLog(Base):
    __tablename__ = "audit_logs"
    id = Column(Integer, primary_key=True); user_id = Column(Integer); action = Column(String(50))
    detail = Column(Text); created = Column(DateTime, default=now)

def hash_pw(p, salt=None):
    salt = salt or os.urandom(8).hex()
    return salt + "$" + hashlib.pbkdf2_hmac("sha256", p.encode(), salt.encode(), 100_000).hex()
def check_pw(p, stored): return hash_pw(p, stored.split("$")[0]) == stored

def get_db():
    db = Session()
    try: yield db
    finally: db.close()

def audit(db, uid, action, detail=""):
    db.add(AuditLog(user_id=uid, action=action, detail=detail[:500])); db.commit()

def init():
    Base.metadata.create_all(engine)
    db = Session()
    if not db.query(User).first():
        p = Patient(code="P-1001", name="Aarav Sharma", age=42, conditions="Hypertension (2021)", meds="Amlodipine 5 mg daily")
        db.add(p); db.flush()
        db.add_all([
            User(username="patient", pw=hash_pw("patient123"), role="patient", name="Aarav Sharma", patient_id=p.id),
            User(username="doctor", pw=hash_pw("doctor123"), role="doctor", name="Dr. Meera Iyer"),
            User(username="hospital", pw=hash_pw("hospital123"), role="hospital", name="City General Admin"),
            LabResult(patient_id=p.id, test="Hemoglobin", value="13.8 g/dL", date="2026-09-12"),
            LabResult(patient_id=p.id, test="LDL cholesterol", value="142 mg/dL (borderline high)", date="2026-09-12"),
            Appointment(patient_id=p.id, doctor="Dr. Meera Iyer (Cardiology)", slot="2026-10-06 10:30"),
        ])
        db.commit()
    db.close()
