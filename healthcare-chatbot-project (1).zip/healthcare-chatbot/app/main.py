import os, re, json, datetime as dt, jwt
from dotenv import load_dotenv
load_dotenv()
from fastapi import FastAPI, Depends, HTTPException
from fastapi.responses import FileResponse
from fastapi.security import HTTPBearer
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from pathlib import Path
from . import db as D, ai, mcp
BASE = Path(__file__).resolve().parent.parent

SECRET = os.getenv("SECRET_KEY", "dev-secret-change-me")
app = FastAPI(title="Healthcare Chatbot")
bearer = HTTPBearer()

@app.on_event("startup")
def startup():
    D.init()
    try: ai.seed()
    except Exception as e: print("Vector seed skipped (is Ollama running?):", e)

# ---------- auth / RBAC / session ----------
class LoginIn(BaseModel): username: str; password: str
class ChatIn(BaseModel): message: str; conversation_id: int | None = None; use_gemini: bool = True
class KnowIn(BaseModel): message_id: int
class DocIn(BaseModel): title: str; kind: str = "Document"; text: str

def current_user(cred=Depends(bearer), db=Depends(D.get_db)):
    try: uid = jwt.decode(cred.credentials, SECRET, algorithms=["HS256"])["uid"]
    except Exception: raise HTTPException(401, "Invalid or expired token")
    u = db.get(D.User, uid)
    if not u: raise HTTPException(401, "Unknown user")
    return u

@app.post("/api/login")
def login(b: LoginIn, db=Depends(D.get_db)):
    u = db.query(D.User).filter_by(username=b.username).first()
    if not u or not D.check_pw(b.password, u.pw): raise HTTPException(401, "Wrong username or password")
    tok = jwt.encode({"uid": u.id, "exp": dt.datetime.utcnow() + dt.timedelta(hours=8)}, SECRET, algorithm="HS256")
    D.audit(db, u.id, "login")
    return {"token": tok, "user": {"name": u.name, "role": u.role}}

# ---------- AI router ----------
def route(q):
    l = q.lower()
    if mcp.pick_tool(q): return "mcp"
    if re.search(r"latest|news|outbreak|current|today|recent|update", l): return "web"
    return "rag"

@app.post("/api/chat")
def chat(b: ChatIn, u=Depends(current_user), db=Depends(D.get_db)):
    conv = db.get(D.Conversation, b.conversation_id) if b.conversation_id else None
    if conv and conv.user_id != u.id: raise HTTPException(403)
    if not conv:
        conv = D.Conversation(user_id=u.id, title=b.message[:50]); db.add(conv); db.commit()
    past = db.query(D.Message).filter_by(conv_id=conv.id).order_by(D.Message.id.desc()).limit(6).all()[::-1]
    history = [{"role": m.role, "content": m.content} for m in past]
    db.add(D.Message(conv_id=conv.id, role="user", content=b.message)); db.commit()
    r, sources = route(b.message), []
    # Gemini only gets public questions: off-switch, or any personal identifiers -> stay on the private LLM
    if r == "web" and (not b.use_gemini or PRIVATE.search(b.message)): r = "rag"
    try:
        if r == "mcp": text, src = mcp.run(b.message, u, db); sources = [src]
        elif r == "web": text, sources = ai.gemini_answer(b.message)
        else: text, sources = ai.rag_answer(b.message, history)
    except PermissionError as e:
        r, text = "denied", f"Your role ({u.role}) is not allowed to use the {e} tool. This attempt was logged."
    except Exception as e:
        text = f"Service error: {e}"
    m = D.Message(conv_id=conv.id, role="assistant", content=text, route=r, sources=json.dumps(sources))
    db.add(m); db.commit()
    D.audit(db, u.id, "chat:" + r, b.message)
    return {"conversation_id": conv.id, "message_id": m.id, "route": r, "answer": text, "sources": sources}

@app.get("/api/status")
def status(u=Depends(current_user)): return ai.status()

@app.get("/api/conversations")
def conversations(u=Depends(current_user), db=Depends(D.get_db)):
    rows = db.query(D.Conversation).filter_by(user_id=u.id).order_by(D.Conversation.id.desc()).limit(30).all()
    return [{"id": c.id, "title": c.title} for c in rows]

@app.get("/api/conversations/{cid}")
def history(cid: int, u=Depends(current_user), db=Depends(D.get_db)):
    c = db.get(D.Conversation, cid)
    if not c or c.user_id != u.id: raise HTTPException(404)
    ms = db.query(D.Message).filter_by(conv_id=cid).order_by(D.Message.id).all()
    return [{"id": m.id, "role": m.role, "content": m.content, "route": m.route, "sources": json.loads(m.sources or "[]")} for m in ms]

# ---------- auto knowledge processor ----------
PRIVATE = re.compile(r"P-\d+|[\w.+-]+@[\w-]+\.\w+|\b\d{10}\b", re.I)

@app.post("/api/knowledge")
def add_knowledge(b: KnowIn, u=Depends(current_user), db=Depends(D.get_db)):
    if u.role == "patient": raise HTTPException(403, "Only doctors/hospital staff can approve knowledge")
    m = db.get(D.Message, b.message_id)
    q = db.query(D.Message).filter(D.Message.conv_id == m.conv_id, D.Message.id < m.id, D.Message.role == "user").order_by(D.Message.id.desc()).first()
    text = f"Q: {q.content if q else ''}\nA: {m.content}"
    checks = [("New", True, ""), ("Relevant", m.route != "denied" and len(m.content) > 40, "too short or denied"), ("Useful", "Service error" not in m.content, "error answer")]
    try:
        top = ai.search(text, 1)
        checks.append(("Not duplicate", not (top and top[0][2] < 0.08), "similar entry exists"))
    except Exception: checks.append(("Not duplicate", True, "skipped"))
    checks.append(("Not private", m.route != "mcp" and not PRIVATE.search(text), "contains patient/personal data"))
    checks.append(("Safe to store", "Service error" not in m.content, ""))
    bad = [c for c in checks if not c[1]]
    out = [{"check": c[0], "ok": c[1], "note": c[2] if not c[1] else ""} for c in checks]
    if bad: return {"stored": False, "checks": out}
    try: n = ai.add_text(re.sub(r"\s+", " ", text).strip(), "Approved Q&A", "Approved Q&A")
    except Exception: raise HTTPException(503, "Embedding model is offline - start Ollama and try again")
    D.audit(db, u.id, "knowledge_add", f"{n} chunks")
    return {"stored": True, "chunks": n, "checks": out}

@app.post("/api/documents")
def upload(b: DocIn, u=Depends(current_user), db=Depends(D.get_db)):
    if u.role == "patient": raise HTTPException(403)
    n = ai.add_text(b.text, b.title, b.kind)
    db.add(D.Document(title=b.title, kind=b.kind, uploaded_by=u.id)); db.commit()
    D.audit(db, u.id, "document_upload", b.title)
    return {"chunks": n}

@app.get("/")
def index(): return FileResponse(BASE / "static" / "index.html")
app.mount("/static", StaticFiles(directory=str(BASE / "static")), name="static")
