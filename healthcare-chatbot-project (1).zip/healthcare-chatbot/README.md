# Healthcare Chatbot (FastAPI + SQL + Private LLM + Gemini)

## Run
1. `python -m venv .venv && source .venv/bin/activate && pip install -r requirements.txt`
2. Install Ollama, then: `ollama pull llama3.1 && ollama pull nomic-embed-text`   (your private LLM + embeddings)
3. `cp .env.example .env` and set `SECRET_KEY` and `GEMINI_API_KEY`
4. `uvicorn app.main:app --reload` -> open http://localhost:8000

Demo logins: patient/patient123, doctor/doctor123, hospital/hospital123 (change before real use).

## Map to your diagram
- Auth/RBAC + sessions: JWT, `current_user`, per-tool role allow-lists (`app/mcp.py`), conversations table
- AI router: `route()` in `app/main.py` -> Private RAG / Gemini web search / MCP tools
- Private RAG: Chroma vector DB + Ollama embeddings and LLM (`app/ai.py`)
- MCP layer: Patient/Doctor/Hospital/Lab/Appointment tools reading SQL (`app/mcp.py`)
- SQL: users, patients, doctors' appointments, conversations, documents, audit logs (`app/db.py`)
- Auto knowledge processor: `/api/knowledge` filter -> chunk -> embed -> store

## Before production
Use HTTPS, a strong SECRET_KEY, Postgres, real user management, and clinical/legal review (HIPAA/DPDP). Never send patient data to Gemini; the router only sends public-info questions there.

## Private LLM and Gemini
- Private LLM backend is set in `.env` (`ollama`, `openai`, or `hf`). Switching the embedding model changes vector size: delete the `chroma/` folder and restart so the knowledge base is re-seeded.
- Gemini is used only for "latest/news/current" questions. The Gemini checkbox in the chat bar turns it off; questions containing patient IDs, emails or phone numbers never go to Gemini.
- The header shows live status of both models (● online, ○ offline / no key).
